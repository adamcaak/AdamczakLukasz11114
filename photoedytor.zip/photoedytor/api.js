document.addEventListener('DOMContentLoaded', function () {

    let loadImageButton = document.querySelector('#load');
    let imageElement = document.querySelector('#image');
    let draw = document.querySelector('#draw');
    let canvas = document.querySelector('canvas');
    let brightness = document.querySelector('#brightness');
    let contrast = document.querySelector('#contrast');
    let saturation = document.querySelector('#saturation');
    let sepia = document.querySelector('#sepia');
    let c = canvas.getContext('2d');
    let pixelData;

    function loadInputHandler(event) {
        let imageFile = event.target.files[0];
        imageElement.setAttribute('src', URL.createObjectURL(imageFile));
    };

    loadImageButton.onchange = loadInputHandler;

    draw.addEventListener('click', function() {
        canvas.width = imageElement.clientWidth;
        canvas.height = imageElement.clientHeight;
        c.drawImage(imageElement, 0, 0, canvas.width, canvas.height);
        pixelData = c.getImageData(0, 0, canvas.width, canvas.height);
    }, false);


    brightness.addEventListener('change', function() {
        c.filter = `brightness(${brightness.value}%)`;
        c.drawImage(imageElement, 0, 0);
    });

    contrast.addEventListener('change', function() {
        c.filter = `contrast(${contrast.value}%)`;
        c.drawImage(imageElement, 0, 0);
    });

    saturation.addEventListener('change', function() {
        c.filter = `saturate(${saturation.value}%)`;
        c.drawImage(imageElement, 0, 0);
    });

    sepia.addEventListener('change', function() {
        c.filter = `sepia(${sepia.value}%)`;
        c.drawImage(imageElement, 0, 0);
    });

}, false);