document.addEventListener("DOMContentLoaded", appStart);
//dzwieki perkusji
const sounds = {
    97: 'boom',
    115: "clap",
    100: "hihat",
    102: "kick",
    103: "openhat",
    104: "ride",
    106: "snare",
    107: "tink",
    108:"tom"
}

//kanaly
let channel1 =[];
let channel2 =[];
let channel3 =[];
let channel4 =[];

//czy wcisniety
let is_Recording = false;
let is_Channel1 = false;
let is_Channel2 = false;
let is_Channel3 = false;
let is_Channel4 = false;

let recStart = null;

function appStart() {
    window.addEventListener('keypress', playSound);
	
    //nagrywanie
    document.querySelector('#rec').addEventListener('click', (e)=>{
        is_Recording = !is_Recording;
        //zapisuje czas
        recStart = Date.now();
        e.target.innerHTML = is_Recording ? 'Stop' : 'Record';
    });
	
    //podpiecie kanalow
    document.querySelector('#channel1').addEventListener('click', (e)=>{
        is_Channel1 = !is_Channel1;
        e.target.innerHTML = is_Channel1 ? "Channel 1" : "Channel 1";
    });
	
    document.querySelector('#channel2').addEventListener('click', (e)=>{
        is_Channel2 = !is_Channel2;
        e.target.innerHTML = is_Channel2 ? "Channel 2" : "Channel 2";
    });
	
    document.querySelector('#channel3').addEventListener('click', (e)=>{
        is_Channel3 = !is_Channel3;
        e.target.innerHTML = is_Channel3 ? "Channel 3" : "Channel 3";
    });
	
    document.querySelector('#channel4').addEventListener('click', (e)=>{
        is_Channel4 = !is_Channel4;
        e.target.innerHTML = is_Channel4 ? "Channel 4" : "Channel 4";
    });
	
    //przyciski odtwarzaj i wyczysc
    document.querySelector('#play').addEventListener('click', playMusic);
    document.querySelector('#clear').addEventListener('click', clearMusic);
}
//czyszczenie tablic
function clearMusic(){
        channel1.splice(0,channel1.length);
        channel2.splice(0,channel2.length);
        channel3.splice(0,channel3.length);
        channel4.splice(0,channel4.length);
}
//odtworzenie dzwiekow z tablicy
function playMusic() {
    channel1.forEach(sound =>{
        setTimeout(
            () => {
                //pobranie nazw dzwiekow
                audioDOM = document.querySelector(`#${sound.sound}`);
                //zerowanie czasu
                audioDOM.currentTime = 0;
                //odtwarzanie
                audioDOM.play();
                }
            ,sound.time //odczytanie czasu z tablicy
        )},
    )
	
    channel2.forEach(sound =>{
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
                }
            ,sound.time
        )},
    )
	
    channel3.forEach(sound =>{
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
                }
            ,sound.time
        )},
    )
	
    channel4.forEach(sound =>{
        setTimeout(
            () => {
                audioDOM = document.querySelector(`#${sound.sound}`);
                audioDOM.currentTime = 0;
                audioDOM.play();
            }
        , sound.time
    )}
)}

function playSound(e) {
    //pobierz nazwe dzwieku
    const soundName = sounds[e.charCode];
    //pobierz uchwyt
    audioDOM = document.querySelector(`#${soundName}`);
    //otworz dzwiek
    audioDOM.currentTime = 0;
    audioDOM.play();
    //wybierz kanal
    //zapisz dzwiek w tablicy
    if(is_Channel1){
        if(is_Recording){
            channel1.push({
                sound: soundName, time: Date.now() - recStart});
        }
    }
	
    if(is_Channel2){
        if(is_Recording){
            channel2.push({sound: soundName, time: Date.now() - recStart});
        }
    }
	
    if(is_Channel3){
        if(is_Recording){
            channel3.push({sound: soundName, time: Date.now() - recStart});
        }
    }
	
    if(is_Channel4){
        if(is_Recording){
            channel4.push({sound: soundName, time: Date.now() - recStart});
        }
    }
}
//mapa przypisuje wartosci do klucza
/*
const s = Map()
s.setItem(true, 'prawda');
*/